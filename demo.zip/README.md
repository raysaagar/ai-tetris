Tetrais - AI Tetris
====================

## Computer Science 182 Final Project - Fall 2013

### Project Members: ###
* Saagar Deshpande
* Louis Li
* Brandon Sim

### Prerequisites ###
--------------
Install pygame using the [binaries](http://www.pygame.org/install.html) for your platform.

For Windows users: Install Colorama library using [PIP for Windows](https://sites.google.com/site/pydatalog/python/pip-for-windows)
